class OutOfRangeError(ValueError):
    pass
