'''
Created on 1 de jun. de 2016

@author: anrecio
'''
import urllib
import urllib2
from VEUtils.pysimplesoap import client
from VEUtils.pysimplesoap.client import SoapClient
from VEUtils import xmltodict
from VEUtils.geo import geoconversion

import  VEUtils.simplejson as json
import datetime
import requests
import xml.etree.ElementTree as ET
import sys

import time
import pika
import json

  
#ESTACION 20009,20005
def ComposeDatagramBus( busValue):
    try:
        global criteria
        
        myCoordinates = [0,0]
        idTrip = "0000".encode("utf-8")
        direction = "0".encode("utf-8")
        status = "0".encode("utf-8")
        delay = "0".encode("utf-8")
        idStop = "0".encode("utf-8")
        estado = "0".encode("utf-8")
        textStop = "####".encode("utf-8")
        offSet = "0".encode("utf-8")
        Z="0".encode("utf-8")
        dataPos = ["0","0"]
    
        idBus = str(busValue['vehiculo']).encode("utf-8")
        if busValue.has_key('viaje'):
            idTrip = str(busValue['viaje']).encode("utf-8")
        if busValue.has_key('sentido'):
            direction = str(busValue['sentido']).encode("utf-8")
        if busValue.has_key('estado'):
            status = str(busValue['estado']).encode("utf-8")
        if busValue.has_key('desfase'):
            delay = str(busValue['desfase']).encode("utf-8")
        if busValue.has_key('posicion'):
            offSet = str(busValue['posicion']).encode("utf-8")

         
        X=0
        Y=0
        if busValue.has_key('gps'):
            busGps = busValue['gps']
            if busGps.has_key('@est'):
                X=busGps['@est']
            else:
                X=0
            if busGps.has_key('@nor'):
                Y=busGps['@nor']
            else:
                Y=0
            if busGps.has_key('@zone'):
                zone=busGps['@zone']
            else:
                zone=0
            
            if X > 0 and Y > 0:
                dataPos = geoconversion.to_latlon(float(X), float(Y)-200, 30, "S") 
            else:
                dataPos = [X,Y]
            
            if busGps.has_key('@alt'):
                Z=str(busGps['@alt']).encode("utf-8")
            else:
                Z="0".encode("utf-8")
            if busValue.has_key('enParada'):
                dataStop = busValue['enParada']
                idStop = str(dataStop['@codigo']).encode("utf-8")
                textStop = str(dataStop['#text']).encode("utf-8")
                
                
            msgLog = " coorx"+str(dataPos[1])+"coort"+str(dataPos[0])
    
            print msgLog 
    
            myCoordinates = [str(dataPos[1]),str(dataPos[0])]
    
        pointData =   {'type':'Point','coordinates':myCoordinates}
        
        datagramHeader={} 
        vep_data=[]
        extraposition={'bus':idBus,"line":idLine,"trip":idTrip,"direction":direction,"status":status,"delay":delay,"stop":idStop,"name":textStop,"offSet":offSet,"altitude":Z,'geometry':pointData}
        datagramHeader["layerData"]={}
        datagramHeader["layerData"]["_id"]=idBus
        datagramHeader["layerData"]["namestudio"]=criteria
        datagramHeader["layerData"]["system"]= "LAYERS"
        datagramHeader["layerData"]["subsystem"]="PUTDATA"
        datagramHeader["layerData"]["function"]="REPLACE"
        datagramHeader["layerData"]["layer"]={}
        datagramHeader["layerData"]["layer"]["owner"]="mobilitylabs.usertest"
        datagramHeader["layerData"]["layer"]["type"]="SHARED"
        datagramHeader["layerData"]["layer"]["name"]="BUSTEST.eventpos"
        datagramHeader["layerData"]["geometry"]=pointData
        datagramHeader["layerData"]["shape"]={}
        datagramHeader["layerData"]["shape"]["type"]="marker"
        datagramHeader["layerData"]["shape"]["options"]={}
        datagramHeader["layerData"]["shape"]["options"]["shape"]="circle"
        datagramHeader["layerData"]["shape"]["options"]["markerColor"]="blue"
        datagramHeader["layerData"]["shape"]["options"]["prefix"]="fa"
        datagramHeader["layerData"]["shape"]["options"]["icon"]="fa-bus"
        datagramHeader["layerData"]["instant"]=str(datetime.datetime.utcnow())
        datagramHeader["layerData"]["busState"]={}
        datagramHeader["layerData"]["busState"]["idLine"]=idLine
        datagramHeader["layerData"]["busState"]["trip"]=idTrip
        datagramHeader["layerData"]["busState"]["direction"]=direction
        datagramHeader["layerData"]["busState"]["status"]=status 
        datagramHeader["layerData"]["busState"]["delay"]=delay 
        datagramHeader["layerData"]["busState"]["offset"]=offSet
        textStatus = "<b><p>Bus Number:"+idBus+"</p><p>Line Number:"+idLine+"</p></b>"
        datagramHeader["layerData"]["state"]={}           
        datagramHeader["layerData"]["state"]["description"]=textStatus
        datagramHeader["layerData"]["state"]["format"]  = "text"
        vep_data.append(datagramHeader)
    
        datagram={}   
        datagram["target"]="datagramServer"
        datagram["vep_data"]=vep_data
        sendRabbit(datagram)
        if busValue.has_key('paradas'):   
            paradasNode = busValue['paradas']
        
            ComposeDatagramStops(extraposition,paradasNode)
            
    except Exception:
        print ("Error building datagram %s" % (sys.exc_info()[1]))   
def DroppingData(nameCol, mode):
        global criteria
        datagramHeader={} 
        vep_data=[]
        datagramHeader["layerData"]={}
        datagramHeader["layerData"]["_id"]="*"
        datagramHeader["layerData"]["system"]= "LAYERS"
        datagramHeader["layerData"]["subsystem"]="PUTDATA"
        datagramHeader["layerData"]["function"]=mode
        datagramHeader["layerData"]["layer"]={}
        datagramHeader["layerData"]["layer"]["owner"]="mobilitylabs.usertest"
        datagramHeader["layerData"]["layer"]["type"]="SHARED"
        datagramHeader["layerData"]["layer"]["name"]=nameCol
        
        datagramHeader["layerData"]["layer"]["criteria"]='{#namestudio#:#'+criteria+'#}'
        datagramHeader["layerData"]["instant"]=str(datetime.datetime.utcnow())

        vep_data.append(datagramHeader)
    
        datagram={}   
        datagram["target"]="datagramServer"
        datagram["vep_data"]=vep_data
        sendRabbit(datagram)    
    
def ComposeDatagramStops(extraposition,paradasNode):

    try:
        global firstTime
        global myEstimations
        global criteria
        
        myCoordinates = [0,0]

        Z="0".encode("utf-8")
        dataPos = ["0","0"]

        X=0
        Y=0
        
        for  stopItem in paradasNode['parada']:
            if stopItem.has_key('@x'):
                X=stopItem['@x']
            else:
                X=0
            if stopItem.has_key('@y'):
                Y=stopItem['@y']
            else:
                Y=0
            if stopItem.has_key('@distancia'):
                distance=stopItem['@distancia']
            else:
                distance=99999
            if stopItem.has_key('@hora'):
                timearrival=stopItem['@hora']
            else:
                timearrival="00:00:00"
                
            
            if X > 0 and Y > 0:
                dataPos = geoconversion.to_latlon(float(X), float(Y)-200, 30, "S")                 
            else:
                dataPos = [X,Y]
            
            
            myCoordinates = [str(dataPos[1]),str(dataPos[0])]
    
            pointData =   {'type':'Point','coordinates':myCoordinates}
            datagram={}    
            datagramHeader={} 
            vep_data=[]
            datagramHeader["layerData"]={}
            datagramHeader["layerData"]["_id"]=stopItem['@codigo'].encode("utf-8")
            datagramHeader["layerData"]["namestudio"]= criteria
            datagramHeader["layerData"]["system"]= "LAYERS"
            datagramHeader["layerData"]["subsystem"]="PUTDATA"
            datagramHeader["layerData"]["function"]="REPLACE"
            datagramHeader["layerData"]["layer"]={}
            datagramHeader["layerData"]["layer"]["owner"]="mobilitylabs.usertest"
            datagramHeader["layerData"]["layer"]["type"]="SHARED"
            datagramHeader["layerData"]["layer"]["name"]="BUSTEST.stoparrives"
            datagramHeader["layerData"]["line"]=extraposition["line"]
            datagramHeader["layerData"]["bus"]=extraposition["bus"]
            if not myEstimations.has_key(stopItem['@codigo']):
                myEstimations[stopItem['@codigo']] = {}
                
            if firstTime:
                datagramHeader["layerData"]["firstTimeArrive"]=timearrival.encode("utf-8")
                myEstimations[stopItem['@codigo']]["firstTimeArrive"]=timearrival.encode("utf-8")
                myEstimations[stopItem['@codigo']]["lastEstimacion"]=timearrival.encode("utf-8")
                
                 
            else:
                
                myEstimations[stopItem['@codigo']]["lastEstimacion"]=timearrival.encode("utf-8")
                

            datagramHeader["layerData"]["geometry"]=pointData
            datagramHeader["layerData"]["estimations"]=myEstimations[stopItem['@codigo']]
            datagramHeader["layerData"]["shape"]={}
            datagramHeader["layerData"]["shape"]["type"]="marker"
            datagramHeader["layerData"]["shape"]["options"]={}
            datagramHeader["layerData"]["state"]={}  
            datagramHeader["layerData"]["shape"]["options"]["shape"]="circle"
            if myEstimations[stopItem['@codigo']]["firstTimeArrive"] == myEstimations[stopItem['@codigo']]["lastEstimacion"]:
            
                datagramHeader["layerData"]["shape"]["options"]["icon"]="fa-stop-circle-o" 
                datagramHeader["layerData"]["state"]["color"]  = "green" 
            elif myEstimations[stopItem['@codigo']]["firstTimeArrive"] > myEstimations[stopItem['@codigo']]["lastEstimacion"]:
              
                datagramHeader["layerData"]["shape"]["options"]["icon"]="fa-thumbs-o-up" 
                datagramHeader["layerData"]["state"]["color"]  = "blue"
            else:
                datagramHeader["layerData"]["shape"]["options"]["icon"]="fa-thumbs-o-down" 
                datagramHeader["layerData"]["state"]["color"]  = "red"
            print stopItem['@codigo']
            if stopItem['@codigo']=="540":
                datagramHeader["layerData"]["shape"]["options"]["markerColor"]="yellow"
            else:
                datagramHeader["layerData"]["shape"]["options"]["markerColor"]="white"
            datagramHeader["layerData"]["shape"]["options"]["prefix"]="fa"
            
            datagramHeader["layerData"]["instant"]=str(datetime.datetime.utcnow())
            datagramHeader["layerData"]["busState"]=extraposition
            textStatus = datagramHeader["layerData"]["namestudio"]
            textStatus+= "<b><p>Stop Number:"+stopItem['@codigo']+"</p><p>Next Bus:"+extraposition["bus"]+"</p><p>line"+extraposition["line"]+'</p>'.encode("utf-8")
            textStatus =textStatus.encode("utf-8")
            textStatus+="<p>First Estimation:"+str(myEstimations[stopItem['@codigo']]["firstTimeArrive"])+"</p>"
            #textStatus+=textStatus.encode("utf-8")
            textStatus+="<p>Last Estimation:"+str(myEstimations[stopItem['@codigo']]["lastEstimacion"])+"</p></b>"
            #textStatus+=textStatus.encode("utf-8")
         
            datagramHeader["layerData"]["state"]["description"]=textStatus.encode("utf-8")
            #datagramHeader["layerData"]["state"]["color"]="#00d63a"
            datagramHeader["layerData"]["state"]["format"]  = "text"
            vep_data.append(datagramHeader)
     
            datagram["target"]="datagramServer"
            datagram["vep_data"]=vep_data
            
            sendRabbit(datagram)
            
    except Exception:
        print ("Error building datagram %s" % (sys.exc_info()[1]))   
def sendRabbit(datagram):
                            
    user = "mobilitylabs.usertest"
    credentSend = pika.PlainCredentials(user, "usertest")
    hostSend = "amqp.emtmadrid.es"
    portSend = 5672
    connection = pika.BlockingConnection(pika.ConnectionParameters(hostSend, portSend, '/', credentSend))

    channel = connection.channel()
    strdatagram=str(datagram).replace("'", '"')
    strdatagram=strdatagram.replace("#", "'")
    channel.basic_publish(exchange='',
                          routing_key='messages',
                          body= strdatagram,
                          properties=pika.BasicProperties(delivery_mode = 2, user_id = user))

    connection.close()
    
    
    
stopFindBusTest=540
lineFind="61"
criteria = "HACKATON_LINEA26_PARADA_540"
DroppingData("BUSTEST.eventpos","DROP")
DroppingData("BUSTEST.stoparrives","DROP")
DroppingData("BUSTEST.traffic","DROP")


#stopFindBusTest=72
ciclos=0
while ciclos< 10:
    urlGetFindBusTest="https://openbus.emtmadrid.es:9443/emt-proxy-server/last/geo/GetArriveStop.php"
    
    useragent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    #params = {'idClient' : 'EMT.SERVICIOS.OPENBUS','passKey' : 'A2C983E5-5BA3-41F3-B47C-428F467041DC','idStop' : stopFindBusTest}
    params = {'idClient' : 'mobilitylabs.usertest','passKey' : 'usertest','idStop' : stopFindBusTest}
    headers = { 'User-Agent' : useragent,'Content-type':'application/x-www-form-urlencoded' }
    
    data = urllib.urlencode(params)
    req = urllib2.Request(urlGetFindBusTest, data, headers)
    response = urllib2.urlopen(req)
    results = response.read()
    resultJson = json.loads(results)
    

    if resultJson.has_key('arrives'):
        resultJsonbus = resultJson['arrives']

        myBusTest = 0
        firstTime = True
        for estim in resultJsonbus:
            
            idLine = str(estim['lineId']).encode("utf-8")
            
            if idLine == lineFind:        
                paradasCount = 1
                paradasPend = 1
                myBusTest = estim['busId']
                myEstimations={}
                while paradasPend <= paradasCount:
                    
                    print "accesing to bus Id..."+myBusTest
                    urlbus = "https://mybus.emtmadrid.es:8073/rests"
                    params="?srv=DatosCoche&paradas=99&bus="+myBusTest
                    aut_h = urllib2.HTTPPasswordMgrWithDefaultRealm()  
                    aut_h.add_password(None, urlbus,  "EMT.SERVICIOS.OPENBUS",  "A2C983E5-5BA3-41F3-B47C-428F467041DC")  
                    handler = urllib2.HTTPBasicAuthHandler(aut_h)
                    opener = urllib2.build_opener(handler)  
                    urllib2.install_opener(opener)  

                    req = urllib2.Request(urlbus+params)
                    
                    response = urllib2.urlopen(req)
                    results = response.read()
        
                    valueDict = xmltodict.parse(results)
                    
                    if valueDict.has_key('DatosCoche'):
            
                        busValue = valueDict['DatosCoche']
        
                        if busValue.has_key('paradas'):   
                            paradasNode = busValue['paradas']
                           
                                
                        ComposeDatagramBus(busValue)
                        if firstTime:
                            paradasPend = len(paradasNode['parada'])
                            paradasCount = len(paradasNode['parada'])
                                
                        else:
                            paradasPend = len(paradasNode['parada'])
                        firstTime = False
                                    
        
                    time.sleep(5)
    DroppingData("BUSTEST.eventpos","DELETE")
    DroppingData("BUSTEST.stoparrives","DELETE")
    DroppingData("BUSTEST.traffic","DELETE")
                    
    ciclos +=1    

