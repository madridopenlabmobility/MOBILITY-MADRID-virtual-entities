'''
Created on 1 de jun. de 2016

@author: anrecio
'''
import urllib
import urllib2
import httplib

from VEUtils.pysimplesoap import client
from VEUtils.pysimplesoap.client import SoapClient
import  VEUtils.simplejson as json

import requests

url = "https://rbdata.emtmadrid.es:8443/DataProvider/api/dmz/getCollection/mobilitylabs.usertest/usertest/Layers/BUSTEST.eventpos/"

payload = "{ \"namestudio\": \"HACKATON_LINEA26_PARADA_540\" }"

headers = {
    'content-type': "application/json",
    'cache-control': "no-cache"

    }

response = requests.request("POST", url, data=payload, headers=headers, verify=False)

print(response.text)
valuejson = eval(response.text)

print valuejson


      
