import time
import datetime
import pika
import json

from MeteorClient import MeteorClient

'''
This code is a example for make a connection from a Reactive Box Mobility Madrid 
The Reactive Box is a Meteor Server which includes many layers of data. 
Current example shows the way of make subscription at value of traffic density in two detectors 
    
For use this program must be include:
MeteorClient https://github.com/hharnisc/python-meteor
EventEmitter https://github.com/jfhbrook/pyee 
Websockets (ws4py on https://github.com/Lawouach/WebSocket-for-Python)
ddpClient https://pypi.python.org/pypi/python-ddp/0.1.0
'''   

dataCol = {}
datagramHeader={} 
vep_data=[]

def sendRabbit(datagram):
                            
    user = "mobilitylabs.usertest"
    credentSend = pika.PlainCredentials(user, "usertest")
    hostSend = "amqp.emtmadrid.es"
    portSend = 5672
    connection = pika.BlockingConnection(pika.ConnectionParameters(hostSend, portSend, '/', credentSend))

    channel = connection.channel()
    strdatagram=str(datagram).replace("'", '"')
    strdatagram=strdatagram.replace("#", "'")
    channel.basic_publish(exchange='',
                          routing_key='messages',
                          body= strdatagram,
                          properties=pika.BasicProperties(delivery_mode = 2, user_id = user))

    connection.close()

def subscribed(subscription):
    print('* SUBSCRIBED {}'.format(subscription))


def unsubscribed(subscription):
    print('* UNSUBSCRIBED {}'.format(subscription))


def added(collection, id, fields):
    print('* ADDED {} {}'.format(collection, id))

    if collection == "users":
        print collection
        #client.subscribe('SENPM25MAD.eventpos.all')
        client.subscribe('BUSTEST.stoparrives.custom',[{'_id':'540'}])
        #codeStation 20009,20005
    elif collection == "BUSTEST.stoparrives":
        client.subscribe('TRAFFICMAD.density.custom',[{'$or': [ {'codeStation': '20009'},{'codeStation': '20005'}]}])
    elif collection == "TRAFFICMAD.density":
        print collection
        print fields
        global dataCol 
        global datagramHeader
        global vep_data
        datagramHeader["layerData"]={}
        datagramHeader["layerData"]["_id"]=fields['codeStation']
        datagramHeader["layerData"]["namestudio"]="HACKATON_LINEA26_PARADA_540"
        datagramHeader["layerData"]["system"]= "LAYERS"
        datagramHeader["layerData"]["subsystem"]="PUTDATA"
        datagramHeader["layerData"]["function"]="REPLACE"
        datagramHeader["layerData"]["layer"]={}
        datagramHeader["layerData"]["layer"]["owner"]="mobilitylabs.usertest"
        datagramHeader["layerData"]["layer"]["type"]="SHARED"
        datagramHeader["layerData"]["layer"]["name"]="BUSTEST.traffic"
        datagramHeader["layerData"]["geometry"]=fields['geometry']
        datagramHeader["layerData"]["shape"]={}
        datagramHeader["layerData"]["shape"]["type"]="marker"
        datagramHeader["layerData"]["shape"]["options"]={}
        datagramHeader["layerData"]["shape"]["options"]["shape"]="circle"
        datagramHeader["layerData"]["shape"]["options"]["markerColor"]="purple"
        
        
        datagramHeader["layerData"]["shape"]["options"]["prefix"]="fa"
        datagramHeader["layerData"]["shape"]["options"]["icon"]="fa-arrows-alt"
        datagramHeader["layerData"]["instant"]=str(datetime.datetime.utcnow())
        datagramHeader["layerData"]['intensity']= fields['intensity']
        datagramHeader["layerData"]['satIntensity']= fields['satIntensity']
        datagramHeader["layerData"]['descripcion']= fields['descripcion']
        
        
        
        datagramHeader["layerData"]["state"]={}           
        datagramHeader["layerData"]["state"]["description"]=fields['state']['description']
        datagramHeader["layerData"]["state"]["format"]  = "text"
        datagramHeader["layerData"]["state"]["color"]  = "white"
        datagramHeader["layerData"]["state"]["value"]  = "1"
        
        vep_data.append(datagramHeader)
      
        datagram={}   
        datagram["target"]="datagramServer"
        datagram["vep_data"]=vep_data
        sendRabbit(datagram)

        
def changed(collection, id, fields, cleared):
    
    print ("changed:{}".format(id)+" fields: {}".format(fields))
    


def connected():
    print('* CONNECTED')
    client.login("mobilitylabs.usertest", "usertest")
 

def subscription_callback(error):
    if error:
        print(error)

try:
    
    client = MeteorClient('ws://rbmobility.emtmadrid.es:3333/websocket',auto_reconnect=True,auto_reconnect_timeout=5,debug=False)

    client.on('subscribed', subscribed)
    client.on('unsubscribed', unsubscribed)
    client.on('added', added)
    client.on('connected', connected)
    client.on('changed',changed)
    
    
    
    client.connect()


    # ctrl + c to kill the script
    while True:
        try:
            time.sleep(1)
        except KeyboardInterrupt:
            break
    
   
    client.subscribe('BUSTEST.stoparrives.custom',[{'_id':'540'}])
    #client.unsubscribe("ROUTESMAD.usrtrack.custom")

except Exception as err :
    print err.message

